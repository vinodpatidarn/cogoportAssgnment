import React, { useState, useEffect } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import { PencilSquare, TrashFill, Plus } from 'react-bootstrap-icons';
import { BrowserRouter as Router, Link } from 'react-router-dom';

const StudentList = () => {
    const [students, setStudents] = useState([]);
    function deleteStudent() {
        axios
            .delete("http://localhost:10524/secret_menu_items/destroy?id=1")
            .then(({ data }) => {
                setStudents(data);
            })
            .catch((error) => {
                console.log(error);
            });
    }
    useEffect(() => {
        axios
            .get("http://localhost:10524/secret_menu_items/")
            .then(({ data }) => {
                setStudents(data);
            })
            .catch((error) => {
                console.log(error);
            });
    }, []);
    //console.log('----------------', students);
    return (
        <>
            <div className="row" style={{ marginTop: "80px", marginBottom: "19rem" }} >
                <div className="col-lg-12">
                    <div className="container">
                        <div>
                            <div>
                                <div className="table-title">
                                    <div className="row">
                                        <div className="col-sm-10"><h2>Student <b>Details</b></h2></div>
                                        <div className="col-sm-2">
                                            <Link type="button" to="/" className="btn btn-danger add-new"><Plus color="blue" size={20} />Add New</Link>
                                        </div>
                                    </div>
                                </div>
                                <table className="table table-stripped">
                                    <thead>

                                        <tr>
                                            <th>id</th>
                                            <th>Roll Number</th>
                                            <th>Name</th>
                                            <th>email</th>
                                            <th>Actions</th>
                                        </tr>

                                    </thead>
                                    <tbody>
                                        {
                                            students.map(item => (
                                                <tr key={item.id}>
                                                    <td>{item.id}</td>
                                                    <td>{item.rollno}</td>
                                                    <td>{item.name}</td>
                                                    <td>{item.email}</td>
                                                    <td>
                                                        <Link type="button" to={`/Edit/${item.id}`} className="btn btn-danger add-new"><PencilSquare color="royalblue" size={20} /></Link>
                                                        <button className="delete btn btn-danger" title="Delete" data-toggle="tooltip"><TrashFill color="royalblue" size={20} onClick={deleteStudent} /></button>
                                                    </td>
                                                </tr>))
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </>
    );
};

export default StudentList;
